CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pasien`
--

DROP TABLE IF EXISTS `pasien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pasien` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `alamat` text,
  `no_telp` varchar(20) DEFAULT NULL,
  `status` enum('Aktif','Nonaktif') DEFAULT 'Aktif',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nik` (`nik`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pasien`
--

LOCK TABLES `pasien` WRITE;
/*!40000 ALTER TABLE `pasien` DISABLE KEYS */;
INSERT INTO `pasien` VALUES (1,'1234567890','Yolo','L','2026-05-01','dasfafesaf','3141414','Aktif'),(2,'3171010101900001','Budi Santoso','L','1990-01-15','Jl. Condet Raya No. 15, Jakarta Timur','081234567001','Aktif'),(3,'3276020202920002','Siti Aminah','P','1992-02-20','Jl. Margonda Raya No. 88, Depok','081345678002','Aktif'),(4,'3174030303850003','Andi Wijaya','L','1985-03-10','Jl. Tebet Barat Dalam No. 12, Jakarta Selatan','081456789003','Aktif'),(5,'3171040404880004','Rina Melati','P','1988-04-05','Jl. Raya Bogor KM 28, Jakarta Timur','081567890004','Aktif'),(6,'3174050505750005','Joko Anwar','L','1975-05-25','Jl. Kemang Raya No. 45, Jakarta Selatan','081678901005','Aktif'),(8,'3171070707820007','Hendra Setiawan','L','1982-07-12','Jl. Pemuda No. 70, Rawamangun, Jakarta Timur','081890123007','Aktif'),(9,'3174080808980008','Ayu Tingting','P','1998-08-18','Jl. Fatmawati No. 33, Jakarta Selatan','081901234008','Aktif'),(10,'3276090909910009','Eko Patrio','L','1991-09-09','Jl. Akses UI No. 99, Kelapa Dua, Depok','082012345009','Aktif'),(11,'3171101010890010','Maya Septha','P','1989-10-22','Jl. Kalimalang Raya No. 5, Jakarta Timur','082123456010','Aktif'),(12,'3174111111770011','Rudi Salim','L','1977-11-11','Jl. Senopati No. 22, Jakarta Selatan','082234567011','Aktif'),(13,'3276121212940012','Nina Zatulini','P','1994-12-01','Jl. Siliwangi No. 44, Pancoran Mas, Depok','082345678012','Aktif'),(14,'3171131313860013','Dwi Sasono','L','1986-01-13','Jl. Dewi Sartika No. 11, Cawang, Jakarta Timur','082456789013','Aktif'),(15,'3174141414990014','Sari Roti','P','1999-02-14','Jl. Panglima Polim No. 7, Jakarta Selatan','082567890014','Aktif'),(16,'3276151515830015','Tono Supartono','L','1983-03-15','Jl. Cinere Raya No. 21, Limo, Depok','082678901015','Aktif'),(17,'123456788','Dika','L','2005-01-01','dafaefaefe','087812345678','Aktif'),(18,'1213455666','rofi satu','L','2013-06-04','adjbkfnasjf','087811223344','Aktif');
/*!40000 ALTER TABLE `pasien` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:15
