CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `layanan`
--

DROP TABLE IF EXISTS `layanan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `layanan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kd_layanan` varchar(20) DEFAULT NULL,
  `nama_layanan` varchar(100) DEFAULT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `harga` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kd_layanan` (`kd_layanan`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layanan`
--

LOCK TABLES `layanan` WRITE;
/*!40000 ALTER TABLE `layanan` DISABLE KEYS */;
INSERT INTO `layanan` VALUES (1,'0301','Scalling Gigi Pembersihan Karang Gigi','Tindakan Medis',350000.00,1,'2026-05-15 17:17:39','2026-05-15 17:17:39'),(2,'0302','Pencabutan Gigi (Eksodonsi)','Tindakan Medis',250000.00,1,'2026-05-15 17:18:48','2026-05-15 17:18:48'),(3,'0303','Tambal Gigi Komposit','Tindakan Medis',400000.00,1,'2026-05-15 17:19:30','2026-05-15 17:19:30'),(4,'0304','Pemasangan Behel (metal brace)','Tindakan Medis',5000000.00,1,'2026-05-15 17:20:58','2026-05-15 17:20:58'),(5,'0305','Kontrol Behel Rutin','Konsultasi',200000.00,1,'2026-05-15 17:21:53','2026-05-15 17:21:53'),(6,'0306','Perawatan Saluran Akar','Tindakan Medis',600000.00,1,'2026-05-15 17:22:38','2026-05-15 17:22:38'),(7,'0307','Odontektomi (Operasi Gigi Bungsu','Tindakan Medis',2000000.00,1,'2026-05-15 17:23:27','2026-05-15 17:23:27'),(8,'0701','Konsultasi Spesialis THT','Konsultasi',250000.00,1,'2026-05-15 17:25:26','2026-05-15 17:25:26'),(9,'0702','Ekstraksi Serumen (Pembersihan Telinga)','Tindakan Medis',150000.00,1,'2026-05-15 17:25:59','2026-05-15 17:25:59'),(10,'0703','Endoskopi THT','Tindakan Medis',500000.00,1,'2026-05-15 17:26:59','2026-05-15 17:26:59'),(11,'0704','Tes Pendengaran (Audiometri)','Pemeriksaan Lab',350000.00,1,'2026-05-15 17:27:38','2026-05-15 17:27:38'),(12,'0705','Pengambilan Benda Asing','Tindakan Medis',400000.00,1,'2026-05-15 17:28:05','2026-05-15 17:28:05'),(13,'0706','Irigasi Telinga','Tindakan Medis',200000.00,1,'2026-05-15 17:28:28','2026-05-15 17:28:28'),(14,'0707','Kauterisasi Hidung (Penanganan Mimisan)','Tindakan Medis',300000.00,1,'2026-05-15 17:29:19','2026-05-15 17:29:19'),(15,'0708','Operasi Amandel (Tonsilektomi)','Tindakan Medis',7500000.00,1,'2026-05-15 17:29:53','2026-05-15 17:29:53'),(16,'0601','Konsultasi Spesialis Mata','Konsultasi',250000.00,1,'2026-05-16 06:44:22','2026-05-16 06:44:22'),(17,'0602','Pemeriksaan Refraksi (Minus/Plus/Silinder0','Tindakan Medis',1000000.00,1,'2026-05-16 06:45:37','2026-05-16 06:45:37'),(18,'0603','Cek Tekanan Bola Mata','Tindakan Medis',150000.00,1,'2026-05-16 06:46:15','2026-05-16 06:46:15'),(19,'0604','Pemeriksaan Saraf Retina','Tindakan Medis',250000.00,1,'2026-05-16 06:46:47','2026-05-16 06:46:47'),(20,'0605','Tes Buta Warna','Tindakan Medis',75000.00,1,'2026-05-16 06:47:15','2026-05-16 06:47:15'),(21,'0606','Pengambilan Benda Asing','Tindakan Medis',300000.00,1,'2026-05-16 06:48:06','2026-05-16 06:48:06'),(22,'0607','Operasi Pterigium (Selaput Mata)','Tindakan Medis',3500000.00,1,'2026-05-16 06:48:45','2026-05-16 06:48:45'),(23,'0608','Operasi Katarak','Tindakan Medis',8500000.00,1,'2026-05-16 06:49:29','2026-05-16 06:49:29'),(24,'0201','Konsultasi Spesialis Anak','Konsultasi',250000.00,1,'2026-05-16 06:51:55','2026-05-16 06:51:55'),(25,'0202','Pemeriksaan Tumbuh Kembang','Lainnya',300000.00,1,'2026-05-16 06:52:47','2026-05-16 06:52:47'),(26,'0203','Imunisasi Anak (BCG/Polio/DPT/Campak)','Tindakan Medis',200000.00,1,'2026-05-16 06:53:39','2026-05-16 06:53:39'),(27,'0204','Imunisasi Pilihan (PCV/Rotavirus/Influenza)','Tindakan Medis',850000.00,1,'2026-05-16 06:54:33','2026-05-16 06:54:33'),(28,'0205','Terapi Uap (Nebulizer)','Lainnya',150000.00,1,'2026-05-16 06:55:25','2026-05-16 06:55:25'),(29,'0206','Tindik Telinga Bayi ','Tindakan Medis',100000.00,1,'2026-05-16 06:55:54','2026-05-16 06:56:09'),(30,'0207','Skrinning Bayi Baru Lahir','Lainnya',450000.00,1,'2026-05-16 06:56:39','2026-05-16 06:56:39'),(31,'0208','Konsultasi Nutrisi dan Laktasi','Konsultasi',250000.00,1,'2026-05-16 06:57:08','2026-05-16 06:57:08'),(32,'0401','Konsultasi Spesialis Kandungan','Konsultasi',300000.00,1,'2026-05-16 06:58:28','2026-05-16 06:58:28'),(33,'0402','USG 2D & Konsultasi Kehamilan','Lainnya',450000.00,1,'2026-05-16 06:59:46','2026-05-16 06:59:46'),(34,'0403','USG 4D (Screening Detail)','Lainnya',800000.00,1,'2026-05-16 07:00:45','2026-05-16 07:00:45'),(35,'0404','Pap Smear (Deteksi Kanker Serviks)','Tindakan Medis',350000.00,1,'2026-05-16 07:01:29','2026-05-16 07:01:29'),(36,'0405','Pemasangan/Pelepasan KB IUD','Tindakan Medis',600000.00,1,'2026-05-16 07:01:51','2026-05-16 07:01:51'),(37,'0406','Imunisasi HPV (Kanker Serviks)','Tindakan Medis',1200000.00,1,'2026-05-16 07:02:18','2026-05-16 07:02:18'),(38,'0407','Paket Persalinan Normal (Tanpa Komplikasi)','Lainnya',12000000.00,1,'2026-05-16 07:02:55','2026-05-16 07:02:55'),(39,'0408','Paket Persalinan Caesar (SC)','Lainnya',25000000.00,1,'2026-05-16 07:03:23','2026-05-16 07:03:23'),(40,'0501','Konsultasi Spesialis Penyakit Dalam','Konsultasi',250000.00,1,'2026-05-16 07:04:10','2026-05-16 07:04:10'),(41,'0502','EKG (Elektrokardiogram) / Rekam Jantung','Tindakan Medis',150000.00,1,'2026-05-16 07:04:44','2026-05-16 07:04:44'),(42,'0503','USG Abdomen (Pemeriksaan Organ Dalam Perut)','Lainnya',500000.00,1,'2026-05-16 07:05:14','2026-05-16 07:05:14'),(43,'0504','Endoskopi Saluran Cerna Atas (Gastroskopi)','Lainnya',2500000.00,1,'2026-05-16 07:05:39','2026-05-16 07:05:39'),(44,'0505','Kolonoskopi (Pemeriksaan Usus Besar)','Lainnya',3000000.00,1,'2026-05-16 07:06:12','2026-05-16 07:06:12'),(45,'0506','Spirometri (Tes Fungsi Paru)','Lainnya',350000.00,1,'2026-05-16 07:06:42','2026-05-16 07:06:42'),(46,'0507','Edukasi & Injeksi Insulin (Diabetes','Lainnya',150000.00,1,'2026-05-16 07:07:07','2026-05-16 07:07:07'),(47,'0508','Vaksinasi Dewasa (Influenza / Pneumonia)','Tindakan Medis',600000.00,1,'2026-05-16 07:07:35','2026-05-16 07:07:35'),(48,'0101','Konsultasi Dokter Umum','Konsultasi',50000.00,1,'2026-05-16 07:53:45','2026-05-16 07:54:40');
/*!40000 ALTER TABLE `layanan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:19
