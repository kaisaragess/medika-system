CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pembayaran`
--

DROP TABLE IF EXISTS `pembayaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembayaran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_pendaftaran` int DEFAULT NULL,
  `no_tagihan` varchar(50) DEFAULT NULL,
  `id_pegawai` int DEFAULT NULL,
  `tgl_bayar` datetime DEFAULT CURRENT_TIMESTAMP,
  `metode_bayar` varchar(50) DEFAULT NULL,
  `total_bayar` decimal(10,2) DEFAULT NULL,
  `status_pembayaran` enum('Belum Lunas','Lunas','Batal') DEFAULT 'Belum Lunas',
  PRIMARY KEY (`id`),
  KEY `id_pendaftaran` (`id_pendaftaran`),
  KEY `id_pegawai` (`id_pegawai`),
  CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pembayaran_ibfk_2` FOREIGN KEY (`id_pegawai`) REFERENCES `pegawai` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembayaran`
--

LOCK TABLES `pembayaran` WRITE;
/*!40000 ALTER TABLE `pembayaran` DISABLE KEYS */;
INSERT INTO `pembayaran` VALUES (1,3,'INV-20260517102856',1,'2026-05-17 10:28:00','Tunai',1600000.00,'Lunas'),(2,3,'INV-20260517102856',1,'2026-05-17 10:28:00','Tunai',1600000.00,'Lunas'),(3,4,'INV-20260517105915',1,'2026-05-17 10:59:00','Tunai',0.00,'Lunas'),(4,5,'INV-20260517110836',1,'2026-05-17 11:08:00','Tunai',5005000.00,'Lunas'),(5,6,'INV-20260518153947',1,'2026-05-18 15:39:00','QRIS',25235000.00,'Lunas'),(6,10,'INV-20260519160402',1,'2026-05-19 16:04:00','Tunai',312000.00,'Lunas'),(7,11,'INV-20260609025512',1,'2026-06-09 02:55:00','QRIS',220000.00,'Lunas'),(8,12,'INV-20260625044211',1,'2026-06-25 04:42:00','Kartu Debit/Kredit',65000.00,'Lunas'),(9,13,'INV-20260625044804',1,'2026-06-25 04:48:00','Tunai',65000.00,'Lunas'),(10,15,'INV-20260702052940',1,'2026-07-02 05:29:00','Asuransi/BPJS',800000.00,'Lunas');
/*!40000 ALTER TABLE `pembayaran` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:14
