CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pendaftaran`
--

DROP TABLE IF EXISTS `pendaftaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pendaftaran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_pendaftaran` varchar(50) DEFAULT NULL,
  `id_pasien` int DEFAULT NULL,
  `id_poli` int unsigned DEFAULT NULL,
  `keluhan_awal` text,
  `tgl_daftar` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Antri','Diperiksa','Selesai','Batal') DEFAULT 'Antri',
  PRIMARY KEY (`id`),
  UNIQUE KEY `no_pendaftaran` (`no_pendaftaran`),
  KEY `id_pasien` (`id_pasien`),
  CONSTRAINT `pendaftaran_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pendaftaran`
--

LOCK TABLES `pendaftaran` WRITE;
/*!40000 ALTER TABLE `pendaftaran` DISABLE KEYS */;
INSERT INTO `pendaftaran` VALUES (1,'REG-20260515-4493',1,NULL,NULL,'2026-05-15 22:21:42','Selesai'),(3,'REG-20260516-6185',2,1,'Batuk','2026-05-16 07:50:56','Selesai'),(4,'REG-20260517-7835',3,4,'nyeri gusi\r\n','2026-05-17 10:57:07','Selesai'),(5,'REG-20260517-6262',4,5,'gigi tidak rapi','2026-05-17 11:05:17','Selesai'),(6,'REG-20260518-1635',17,8,'bayi 12 bulan ga lahir\r\n','2026-05-18 15:36:55','Selesai'),(8,'REG-20260519-4892',2,1,'ijjojnin','2026-05-19 15:52:34','Selesai'),(9,'REG-20260519-8877',17,4,'kokokokok','2026-05-19 15:55:18','Selesai'),(10,'REG-20260519-8389',12,9,'ksokdokaof','2026-05-19 15:58:37','Selesai'),(11,'REG-20260609-3986',18,4,'gusi berdarah\r\n','2026-06-09 02:53:17','Selesai'),(12,'REG-20260625-8375',4,1,'sakit perut','2026-06-25 04:40:32','Selesai'),(13,'REG-20260625-1181',17,8,'sakit gigi','2026-06-25 04:46:14','Selesai'),(14,'REG-20260625-1966',6,9,'nyeri bagian belakang punggung\r\n','2026-06-25 04:50:41','Batal'),(15,'REG-20260702-2408',5,1,'batuk','2026-07-02 05:26:11','Diperiksa');
/*!40000 ALTER TABLE `pendaftaran` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:17
