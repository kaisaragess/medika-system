CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rekam_medis`
--

DROP TABLE IF EXISTS `rekam_medis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rekam_medis` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kd_rekam_medis` varchar(50) DEFAULT NULL,
  `id_pendaftaran` int DEFAULT NULL,
  `id_pegawai` int DEFAULT NULL,
  `tanggal_periksa` date DEFAULT NULL,
  `keluhan` text,
  `diagnosa` text,
  `tindakan_medis` text,
  `tekanan_darah` varchar(20) DEFAULT NULL,
  `file` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kd_rekam_medis` (`kd_rekam_medis`),
  KEY `id_pendaftaran` (`id_pendaftaran`),
  KEY `id_pegawai` (`id_pegawai`),
  CONSTRAINT `rekam_medis_ibfk_1` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rekam_medis_ibfk_2` FOREIGN KEY (`id_pegawai`) REFERENCES `pegawai` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rekam_medis`
--

LOCK TABLES `rekam_medis` WRITE;
/*!40000 ALTER TABLE `rekam_medis` DISABLE KEYS */;
INSERT INTO `rekam_medis` VALUES (1,'RM-20260515-644',1,3,'2026-05-15','ffF','dfdF','dFdF','120/80',NULL),(2,'RM-20260515-578',1,2,'2026-05-15','agga','agag','gaga','gag',NULL),(3,'RM-20260516-344',3,3,'2026-05-16','batuk','infeksi saluran pernapasan','kasih obat','120',NULL),(4,'RM-20260517-690',4,7,'2026-05-17','nyeri  gusi','adalah pokoknya','yang tau tau aja','120/80','1779015491_152614776e4ee847d2bf.pdf'),(5,'RM-20260517-248',5,7,'2026-05-17','gigi tidak rapi','gigi bawah maju ke depan','pemasangan behel','120/4',NULL),(6,'RM-20260518-893',6,7,'2026-05-18','gdshsdh','dagdgsag','vzdfdg','235/10000',NULL),(8,'RM-20260519-265',8,7,'2026-05-19','ijjojnin','jiojoiji','jninijn','11/11',NULL),(9,'RM-20260519-600',9,3,'2026-05-19','kokokokok','jnninj','jnjnijn','120/30',NULL),(10,'RM-20260519-214',10,7,'2026-05-19','ksokdokaof','janggal','dfafdaf','120/212',NULL);
/*!40000 ALTER TABLE `rekam_medis` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:18
