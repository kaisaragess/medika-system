CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `obat`
--

DROP TABLE IF EXISTS `obat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kd_obat` varchar(20) DEFAULT NULL,
  `nama_obat` varchar(100) DEFAULT NULL,
  `jenis` varchar(50) DEFAULT NULL,
  `dosis` varchar(50) DEFAULT NULL,
  `satuan` varchar(50) DEFAULT NULL,
  `harga` decimal(10,2) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `expired` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kd_obat` (`kd_obat`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obat`
--

LOCK TABLES `obat` WRITE;
/*!40000 ALTER TABLE `obat` DISABLE KEYS */;
INSERT INTO `obat` VALUES (1,'KAPS-001','Amoxicillin','Kapsul','500mg','Strip',15000.00,98,'2027-12-31'),(2,'KAPS-002','Omeprazole','Kapsul','20mg','Strip',25000.00,20,'2028-06-30'),(3,'KAPS-003','Loperamide','Kapsul','2mg','Strip',10000.00,75,'2027-10-15'),(4,'TAB-001','Paracetamol','Tablet','500mg','Strip',5000.00,199,'2028-01-01'),(5,'TAB-002','Amlodipine','Tablet','10mg','Strip',12000.00,149,'2027-08-20'),(6,'TAB-003','Metformin','Tablet','500mg','Strip',18000.00,120,'2029-02-28'),(7,'SYR-001','Sanmol','Sirup','120mg/5ml','Botol',20000.00,39,'2027-05-10'),(8,'SYR-002','Ambroxol','Sirup','15mg/5ml','Botol',18000.00,60,'2028-03-12'),(9,'SYR-003','Ibuprofen','Sirup','100mg/5ml','Botol',25000.00,34,'2027-11-30'),(10,'SLP-001','Ketoconazole Cream','Salep','2%','Tube',15000.00,49,'2028-09-01'),(11,'SLP-002','Hydrocortisone Cream','Salep','2.5%','Tube',12000.00,45,'2027-07-15'),(12,'SLP-003','Gentamicin Ointment','Salep','0.1%','Tube',10000.00,60,'2029-01-20'),(13,'INJ-001','Ceftriaxone','Injeksi','1g','Vial',50000.00,80,'2028-12-31'),(14,'INJ-002','Ondansetron','Injeksi','4mg/2ml','Ampul',35000.00,99,'2027-04-30'),(15,'INJ-003','Dexamethasone','Injeksi','5mg/ml','Ampul',15000.00,150,'2028-10-10');
/*!40000 ALTER TABLE `obat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:16
