CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaksi_obat`
--

DROP TABLE IF EXISTS `transaksi_obat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi_obat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_pendaftaran` int DEFAULT NULL,
  `id_obat` int DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `aturan_pakai` varchar(100) DEFAULT NULL,
  `tagihan_obat` decimal(10,2) DEFAULT NULL,
  `tgl_transaksi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_pendaftaran` (`id_pendaftaran`),
  KEY `id_obat` (`id_obat`),
  CONSTRAINT `transaksi_obat_ibfk_1` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaksi_obat_ibfk_2` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi_obat`
--

LOCK TABLES `transaksi_obat` WRITE;
/*!40000 ALTER TABLE `transaksi_obat` DISABLE KEYS */;
INSERT INTO `transaksi_obat` VALUES (1,3,NULL,NULL,NULL,NULL,'2026-05-16 16:26:23'),(2,3,NULL,NULL,NULL,NULL,'2026-05-16 16:34:47'),(3,4,NULL,NULL,NULL,NULL,'2026-05-17 17:59:09'),(4,4,NULL,NULL,NULL,NULL,'2026-05-17 18:00:54'),(5,4,1,1,'3x1',15000.00,'2026-05-17 18:04:33'),(6,5,4,1,'3x1',5000.00,'2026-05-17 18:08:19'),(7,6,14,1,'1x1',35000.00,'2026-05-18 22:38:30'),(9,10,5,1,'1x1',12000.00,'2026-05-19 23:03:33'),(10,11,7,1,'3x1',20000.00,'2026-06-09 09:54:56'),(11,12,1,1,'3x1',15000.00,'2026-06-25 11:42:00'),(12,13,10,1,'3x1',15000.00,'2026-06-25 11:47:56'),(13,15,2,30,'3x1',750000.00,'2026-07-02 12:29:09');
/*!40000 ALTER TABLE `transaksi_obat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:18
