CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `detail_pembayaran`
--

DROP TABLE IF EXISTS `detail_pembayaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_pembayaran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_pembayaran` int DEFAULT NULL,
  `jenis_item` varchar(50) DEFAULT NULL,
  `nama_item` varchar(100) DEFAULT NULL,
  `biaya` decimal(10,2) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pembayaran` (`id_pembayaran`),
  CONSTRAINT `detail_pembayaran_ibfk_1` FOREIGN KEY (`id_pembayaran`) REFERENCES `pembayaran` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_pembayaran`
--

LOCK TABLES `detail_pembayaran` WRITE;
/*!40000 ALTER TABLE `detail_pembayaran` DISABLE KEYS */;
INSERT INTO `detail_pembayaran` VALUES (1,1,'Layanan','Total Tagihan Layanan Medis',100000.00,1,100000.00),(2,1,'Kamar','Total Tagihan Rawat Inap',1500000.00,1,1500000.00),(3,2,'Layanan','Total Tagihan Layanan Medis',100000.00,1,100000.00),(4,2,'Kamar','Total Tagihan Rawat Inap',1500000.00,1,1500000.00),(5,4,'Obat','Resep Obat: Paracetamol',5000.00,1,5000.00),(6,4,'Layanan','Tindakan/Layanan: Pemasangan Behel (metal brace)',5000000.00,1,5000000.00),(7,5,'Obat','Resep Obat: Ondansetron',35000.00,1,35000.00),(8,5,'Layanan','Tindakan/Layanan: Paket Persalinan Caesar (SC)',25000000.00,1,25000000.00),(9,5,'Kamar','Rawat Inap: Kamar KMR-3-02 (Kelas 3)',200000.00,1,200000.00),(10,6,'Obat','Resep Obat: Amlodipine',12000.00,1,12000.00),(11,6,'Layanan','Tindakan/Layanan: Tindik Telinga Bayi ',100000.00,1,100000.00),(12,6,'Kamar','Rawat Inap: Kamar KMR-3-02 (Kelas 3)',200000.00,1,200000.00),(13,7,'Obat','Resep Obat: Sanmol',20000.00,1,20000.00),(14,7,'Layanan','Tindakan/Layanan: Kontrol Behel Rutin',200000.00,1,200000.00),(15,8,'Obat','Resep Obat: Amoxicillin',15000.00,1,15000.00),(16,8,'Layanan','Tindakan/Layanan: Konsultasi Dokter Umum',50000.00,1,50000.00),(17,9,'Obat','Resep Obat: Ketoconazole Cream',15000.00,1,15000.00),(18,9,'Layanan','Tindakan/Layanan: Konsultasi Dokter Umum',50000.00,1,50000.00),(19,10,'Obat','Resep Obat: Omeprazole',25000.00,30,750000.00),(20,10,'Layanan','Tindakan/Layanan: Konsultasi Dokter Umum',50000.00,1,50000.00);
/*!40000 ALTER TABLE `detail_pembayaran` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:16
