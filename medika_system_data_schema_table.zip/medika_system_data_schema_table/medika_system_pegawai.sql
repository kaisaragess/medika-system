CREATE DATABASE  IF NOT EXISTS `medika_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medika_system`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: medika_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pegawai`
--

DROP TABLE IF EXISTS `pegawai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pegawai` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_poli` int DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` text,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `spesialisasi` varchar(100) DEFAULT NULL,
  `nomor_telp` varchar(20) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `id_poli` (`id_poli`),
  CONSTRAINT `pegawai_ibfk_1` FOREIGN KEY (`id_poli`) REFERENCES `poliklinik` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pegawai`
--

LOCK TABLES `pegawai` WRITE;
/*!40000 ALTER TABLE `pegawai` DISABLE KEYS */;
INSERT INTO `pegawai` VALUES (1,NULL,'kaisar','','kaisar','$2y$10$Ew9i9ED9iDJltbxvS6dZleD2UVxsDX9yEY71v90NYCK7uepMhg5n6',NULL,1,'','123456','Admin'),(2,NULL,'ages',NULL,'ages','$2y$10$Gm/cpM8xlyKCvnmfE2Kl1eaTJtmOwPevUk5PZ1cPwQZDA4KgRKWF6',NULL,1,NULL,'11111','Dokter'),(3,10,'qeurio','adsada','querio','$2y$10$cSKNZFEKKBqKFhukpd5mP..fw/DyI4aT30PHUBl.vBj9UqKftRkEy',NULL,1,'mata','087844338679','Dokter'),(5,NULL,'kaisar kasir','Jalan2','kaisar_kasir','$2y$10$xeA/wZvbKKzU7BRM0wwNpu.FmDI4FQjUkWNK3QiqcHmraVjeBkXmy',NULL,1,NULL,'08123456789','Kasir'),(6,NULL,'kaisar suster','Jalan Bakti','kaisar_suster','$2y$10$sPrKZ5STb7uj5ppDM3eSbu7EBdMnXTJ0XHtAHnVPNKxSEIEqalAKq',NULL,1,NULL,'087844338679','Perawat'),(7,1,'kaisar_dokter','Jalan dokter kaisar','kaisar_dokter','$2y$10$iHT7cC7FWtZeghXoZyqgx.T7Z4S0no8Nd3mmbrpPSTxpAj/KgSppW',NULL,1,'umum','087844338679','Dokter');
/*!40000 ALTER TABLE `pegawai` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 14:27:15
